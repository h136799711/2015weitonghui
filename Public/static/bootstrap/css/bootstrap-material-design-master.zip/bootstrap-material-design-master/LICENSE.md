Bootstrap Material Design theme
Copyright (C) 2014+  Federico Zivolo

This program is free software: you can redistribute it and/or modify
it under the terms you can find below.

You can use this software for free only for no-profit projects.
If you'd like to use this software in a commercial project you may
contact the author (Federico Zivolo) of the software and ask for his
permission and fulfill his conditions.

You can edit and/or redistribute this software only providing a copy
of this license with it.

You cannot sell this software, any change to the software must be
published under the same license of the original software, in case you
don't want to publish your changes you can use a different license.
It will be valid only if your changes are not published but
keep private for personal projects or closed-source projects, in case
you want to publish your changes you must switch again to the original
license provided with the software.

This software can be sold if used inside a software which uses it as
dependency, in any case, this license must be included in the
software.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

This license could be edited in any moment without alert.

Here are listed the authorized individuals and companies and the specific of their licenses:

- **A*Star Education Ltd**: unlimited usage for websites and webapplications of the company.
